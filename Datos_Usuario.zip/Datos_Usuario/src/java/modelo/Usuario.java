package modelo;
public class Usuario {

    int idusu;
    String num_docu;
    String nombre;
    String apellido;
    String email;
    String telefono;

    public Usuario() {
    }

    public Usuario(int idusu, String num_docu, String nombre, String apellido, String email,
            String telefono) {
        this.idusu = idusu;
        this.num_docu = num_docu;
        this.nombre = nombre;
        this.apellido = apellido;
        this.email = email;
        this.telefono = telefono;
    }

    public int getIdusu() {
        return idusu;
    }

    public void setIdusu(int idusu) {
        this.idusu = idusu;
    }

    public String getNum_docu() {
        return num_docu;
    }

    public void setNum_docu(String num_docu) {
        this.num_docu = num_docu;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

}
